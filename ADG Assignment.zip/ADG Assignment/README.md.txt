User interface is containing input field to put game type in.Allowed Bet type is mentioned below the text field and also there is an
area where information about the game is presented. 

App is Accessing API data using axios.

Tech Stack:
axios: 0.19.2
react:16.13.1
react-dom:16.13.1
react-scripts:3.4.1



Lunch the frontend:

1.Open a new terminal window and navigate inside the 'Frontend' folder -
  npm install

2.Run the start script- 
  npm start

Your app should be running on: http://localhost:3000

3.Enter the Game type in Text Box.

4.Click on the submit to see the Race information.


