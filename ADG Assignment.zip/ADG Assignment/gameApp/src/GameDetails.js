import React from "react";
import axios from "axios";

export default class GameDetails extends React.Component {
    constructor(props) {
        super(props);
        console.log(this.props.gameId);
        this.state = {
            id: "",
            races: [],
            status: "",
           
            
        }
        this.getData=this.getData.bind(this);
        this.setResponse=this.setResponse.bind(this);
    }

    getData(url, callBack) {
        console.log(url);
        axios.get(url)
            .then(function (response) {
                
                if (callBack && response) callBack(response);
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            });
    }

    setResponse(response) {
        if (response.data) {
            this.setState({races:response.data.races });
        }
    }

    componentDidMount() {

       
             let url = "https://www.atg.se/services/racinginfo/v1/api/games/" + this.props.gameId;
             console.log(this.props.gameId);
             this.getData(url, this.setResponse);

         }


    componentWillReceiveProps(nextprops) {
       if(this.props.gameId !== nextprops.gameId) {
            let url = "https://www.atg.se/services/racinginfo/v1/api/games/" + this.props.gameId;
            console.log(this.props.gameId);
            this.getData(url, this.setResponse);
            
        }
    }
    

    getGameDetails() {
        console.log(this.state.races);
        return  this.state.races.map(x => {
            return (
                <div className="d-flex p-3 bg-secondary text-black" key={x.id} id={x.id}>
                    
                    <div className="p-2 bg-primary"><b><font color='black'> RaceDate:</font></b><br></br>{x.date}</div>
                    <div className="p-2 bg-info"><b><font color='black'>GameName:</font></b><br></br>{x.name}</div>
                    <div className="p-2 bg-warning"><b><font color='black'>GameStartTime:</font></b><br></br>{x.scheduledStartTime}</div>
                    <div className="p-2 bg-primary">{x.starts.map(x => {
                        return (
                            <div className="d-flex p-3 bg-secondary text-white" key={x.horse.name} id={x.horse.name}>
                            <table className="table table-bordered">
                             <tbody>
                             <tr className="table-danger d-flex">
                             <td className="col-3"><b>DriverName:</b><br></br>{x.driver.firstName + x.driver.lastName}</td>
                             <td className="col-3"><b>HorseName:</b><br></br>{x.horse.name}</td>
                             <td className="col-3"><b>TrainerName:</b><br></br>{x.horse.trainer.firstName+x.horse.trainer.lastName}</td>
                             <td className="col-3"><b>Horse's Father Name:</b><br></br>{x.horse.pedigree.father.name}</td>
                               </tr>
                              </tbody>
                            </table>
                            
                            </div>
                        )
                    })}</div>
                    </div>
                
            )
        })
    }


    render() {
       
        return (
            <div className="col-6">
                <div>{this.state.id}</div>
                <div>{this.state.status}</div>
                {this.getGameDetails()}
            </div>
        )
    }
}
