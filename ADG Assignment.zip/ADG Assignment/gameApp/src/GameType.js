import React, { Component } from 'react'
//import log from 'loglevel';

 
export default class GameType extends Component {
    constructor(props) {
        super(props)
        this.state = {
            value: ""
            }
    }
 
    onGameTypeChangeHandler(e) {

        
         this.setState({
            value: e.target.value
        })
    }
   
     
        

 
    onBlurHandler(e) {
        const { value } = this.state;
        if (value==="V75"||value==="V4"|value==="V64"||value==="V65")this.props.updateGameType(value)
        else this.props.setFalseState()
    }
 
    render() {
        return (
            <div>
                <label><b><font color='red'>GameType:</font></b></label>
                <input type="text"  
                    placeholder="Enter Game Type"
                    value={this.state.value}
                    name="gameType" 
                    onChange={this.onGameTypeChangeHandler.bind(this)} />
                    <button onClick={this.onBlurHandler.bind(this)}><b>Submit</b></button>
                    
                    <div className="col-xs-10"></div>
                    <small className="text-muted"><font color='red'><b>Allowed GameTypes are V4,V75,V64,V65.</b></font></small>
                   
                   
              </div>
        )
    }
}