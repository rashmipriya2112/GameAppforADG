import React, { Component } from 'react'
import axios from 'axios';
import GameDetails from './GameDetails';

//let displayHedding=false;

export default class GameInformation extends Component {
    constructor(props) {
        super(props)

        this.state = {
            upcoming: [],
            result: []
        }
        this.setResponse=this.setResponse.bind(this);
    }

    getData(url, callBack) {
        axios.get(url)
            .then(function (response) {
                if (callBack && response) callBack(response);
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            });
    }

    setResponse(response) {
        if (response.data) {
            this.setState({...response.data });
        }
        else{ 
            this.setState({
                result:[]
            })
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.gameType !== this.props.gameType) {
            
            const url = "https://www.atg.se/services/racinginfo/v1/api/products/" + nextProps.gameType;
            this.getData(url, this.setResponse);
        }
    }

    getGameInformation() {
        const races = this.state.upcoming.length > 0 ? this.state.upcoming : this.state.result.length > 0 ? this.state.result : [];
        
        let val=null;
        if (races.length <= 0){ val=null}

        else{
            
            val= races.map(race => {
            console.log();
            return <div key={race.id} id={race.id}>
                
                <div className="row" onClick={() => { this.setState({ selectedGameId: race.id }) }}>
                    <div className="col-sm-4"><b>RaceNumber:{race.id}</b></div>
                    <div className="col-sm-4"><b>RaceStartTime:{race.startTime}</b></div>
                </div>
                {
                   // this.state.selectedGameId == race.id &&
                    <div className="row">
                        <GameDetails gameId={race.id} />
                    </div>
                    
                }
                
                
                
                
            </div>})
        }
        return val
        }


    render() {
        

        return (
            <div  className="container">
                <div className="d-flex justify-content-between bd-highlight mb-3 pr-2 align-items-center"></div>
                {!this.props.falseState && <h3 className="mt-5 mb-2 d-flex align-items-start">Game Information:</h3>}
               
                {!this.props.falseState && this.getGameInformation()}
            </div>
        )
    }
    }