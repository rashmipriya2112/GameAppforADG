import React from 'react';
import './App.css';
import GameType from './GameType';
import GameInformation from './GameInformation';
 
class App extends React.Component {
 
  constructor(props) {
    super(props)
 
    this.state = {
      gameType: "something",
      value:{},
      falseState:false
    }
  }
 
  updateGameType(gameType) {
    this.setState({ falseState: false})
    this.setState({ gameType: gameType })
  }
 
  onBlurHandler(gameType) {
    
    console.log(gameType)
    this.setState({ gameType })
  }
  
  setFalseState() {
    this.setState({ falseState: true})
  }

  render() {
    const { gameType ,falseState} = this.state
    return (
      <div className="App" >
        <GameType
          updateGameType={this.updateGameType.bind(this)}
          onBlurHandler={this.onBlurHandler.bind(this)}
          setFalseState={this.setFalseState.bind(this)}
        />
        <GameInformation
          gameType={gameType}
          falseState={falseState}
        />
      </div>
    );
  }
}
 
export default App;